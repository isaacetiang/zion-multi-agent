"""
Simple Example - Getting Started with Multi-Agent System

This is the simplest possible example to get you started quickly.
"""
from orchestrator import MultiAgentSystem

# Create the system
system = MultiAgentSystem("My First Team")

# Create a standard team (Researcher, Analyst, Writer, Critic)
team = system.create_standard_team()

# Run a research pipeline on any topic you want
topic = "Space Exploration"
print(f"\n🔬 Researching: {topic}\n")

result = system.run_research_pipeline(topic, depth="medium")

# Print the final report
print("\n" + "="*60)
print("FINAL REPORT")
print("="*60)

writer_output = result.get("results", {}).get("step_3", {})
if "content" in writer_output:
    print(writer_output["content"])

# Print review feedback
print("\n" + "="*60)
print("REVIEW")
print("="*60)

critic_output = result.get("results", {}).get("step_4", {})
if critic_output:
    print(f"Score: {critic_output.get('overall_score', 0)}/100")
    print(f"Approved: {'Yes' if critic_output.get('approved') else 'No'}")

print("\n✅ Done!")
