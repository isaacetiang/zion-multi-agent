"""
Base Agent Module - Foundation for all specialized agents
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json
import uuid


class MessageType(Enum):
    """Types of messages agents can exchange"""
    TASK = "task"
    RESULT = "result"
    QUERY = "query"
    RESPONSE = "response"
    BROADCAST = "broadcast"
    STATUS = "status"


@dataclass
class Message:
    """Message structure for inter-agent communication"""
    sender: str
    recipient: str
    content: Any
    msg_type: MessageType
    timestamp: datetime = field(default_factory=datetime.now)
    msg_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "msg_id": self.msg_id,
            "sender": self.sender,
            "recipient": self.recipient,
            "content": self.content,
            "msg_type": self.msg_type.value,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata
        }


@dataclass
class AgentState:
    """Tracks agent's current state"""
    status: str = "idle"  # idle, working, waiting, completed, error
    current_task: Optional[str] = None
    completed_tasks: List[str] = field(default_factory=list)
    knowledge: Dict[str, Any] = field(default_factory=dict)
    last_updated: datetime = field(default_factory=datetime.now)


class Agent(ABC):
    """
    Abstract Base Class for all agents
    
    Provides:
    - Unique identity
    - Message handling
    - State management
    - Inter-agent communication
    """
    
    def __init__(self, name: str, role: str, description: str = ""):
        self.name = name
        self.role = role
        self.description = description
        self.agent_id = str(uuid.uuid4())
        self.state = AgentState()
        self.inbox: List[Message] = []
        self.outbox: List[Message] = []
        self.message_handlers: Dict[MessageType, Callable] = {}
        self.peers: Dict[str, 'Agent'] = {}
        self.memory: List[Dict] = []
        
        # Register default handlers
        self._register_default_handlers()
    
    def _register_default_handlers(self):
        """Register default message handlers"""
        self.message_handlers[MessageType.TASK] = self._handle_task
        self.message_handlers[MessageType.QUERY] = self._handle_query
        self.message_handlers[MessageType.STATUS] = self._handle_status
    
    def register_peer(self, agent: 'Agent'):
        """Register another agent as a peer"""
        self.peers[agent.name] = agent
    
    def send_message(self, recipient: str, content: Any, msg_type: MessageType, 
                     metadata: Dict[str, Any] = None) -> Message:
        """Send a message to another agent"""
        msg = Message(
            sender=self.name,
            recipient=recipient,
            content=content,
            msg_type=msg_type,
            metadata=metadata or {}
        )
        self.outbox.append(msg)
        
        # Direct delivery if peer is registered
        if recipient in self.peers:
            self.peers[recipient].receive_message(msg)
        
        return msg
    
    def broadcast(self, content: Any, msg_type: MessageType = MessageType.BROADCAST,
                  metadata: Dict[str, Any] = None):
        """Broadcast message to all peers"""
        for peer_name in self.peers:
            self.send_message(peer_name, content, msg_type, metadata)
    
    def receive_message(self, message: Message):
        """Receive a message"""
        self.inbox.append(message)
        self.memory.append({
            "type": "received",
            "message": message.to_dict()
        })
        self._process_message(message)
    
    def _process_message(self, message: Message):
        """Process incoming message"""
        handler = self.message_handlers.get(message.msg_type)
        if handler:
            handler(message)
        else:
            self._handle_unknown(message)
    
    def _handle_task(self, message: Message):
        """Default task handler - to be overridden"""
        pass
    
    def _handle_query(self, message: Message):
        """Default query handler - to be overridden"""
        pass
    
    def _handle_status(self, message: Message):
        """Default status handler"""
        pass
    
    def _handle_unknown(self, message: Message):
        """Handle unknown message types"""
        print(f"[{self.name}] Unknown message type: {message.msg_type}")
    
    @abstractmethod
    def execute(self, task: Dict[str, Any]) -> Any:
        """Execute a task - must be implemented by subclasses"""
        pass
    
    def update_state(self, **kwargs):
        """Update agent state"""
        for key, value in kwargs.items():
            if hasattr(self.state, key):
                setattr(self.state, key, value)
        self.state.last_updated = datetime.now()
    
    def get_status(self) -> Dict:
        """Get current agent status"""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "role": self.role,
            "status": self.state.status,
            "current_task": self.state.current_task,
            "completed_tasks_count": len(self.state.completed_tasks),
            "inbox_count": len(self.inbox),
            "outbox_count": len(self.outbox),
            "peers": list(self.peers.keys())
        }
    
    def __repr__(self):
        return f"Agent({self.name} | {self.role} | {self.state.status})"
