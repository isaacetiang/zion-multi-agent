"""
Multi-Agent System Package

A flexible framework for building collaborative multi-agent systems.
"""

from agent_base import Agent, Message, MessageType, AgentState
from specialized_agents import (
    ResearchAgent,
    AnalysisAgent,
    WriterAgent,
    CriticAgent,
    CoordinatorAgent
)
from orchestrator import MultiAgentSystem, Workflow, WorkflowStep
from visualization import AgentVisualizer

__version__ = "1.0.0"
__all__ = [
    "Agent",
    "Message",
    "MessageType",
    "AgentState",
    "ResearchAgent",
    "AnalysisAgent",
    "WriterAgent",
    "CriticAgent",
    "CoordinatorAgent",
    "MultiAgentSystem",
    "Workflow",
    "WorkflowStep",
    "AgentVisualizer"
]
