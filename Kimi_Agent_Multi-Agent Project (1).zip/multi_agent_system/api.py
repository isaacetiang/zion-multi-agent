"""
REST API for Multi-Agent System

Run: python api.py
Or: uvicorn api:app --reload (for FastAPI version)
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import uuid
from datetime import datetime

from orchestrator import MultiAgentSystem
from specialized_agents import ResearchAgent, AnalysisAgent, WriterAgent, CriticAgent

app = Flask(__name__)
CORS(app)

# Store active systems
systems = {}


@app.route('/')
def index():
    """API home"""
    return jsonify({
        "name": "Multi-Agent System API",
        "version": "1.0.0",
        "endpoints": [
            "/system/create",
            "/system/<id>/status",
            "/system/<id>/agents",
            "/research",
            "/workflow/create",
            "/workflow/<id>/execute",
            "/agents/list"
        ]
    })


@app.route('/system/create', methods=['POST'])
def create_system():
    """Create a new multi-agent system"""
    data = request.json or {}
    name = data.get('name', f'System-{len(systems)+1}')
    
    system = MultiAgentSystem(name)
    system_id = str(uuid.uuid4())[:8]
    systems[system_id] = system
    
    # Optionally create standard team
    if data.get('create_team', True):
        system.create_standard_team()
    
    return jsonify({
        "system_id": system_id,
        "name": name,
        "agents_count": len(system.agents),
        "created_at": datetime.now().isoformat()
    })


@app.route('/system/<system_id>/status', methods=['GET'])
def get_system_status(system_id):
    """Get system status"""
    if system_id not in systems:
        return jsonify({"error": "System not found"}), 404
    
    system = systems[system_id]
    return jsonify(system.get_system_status())


@app.route('/system/<system_id>/agents', methods=['GET'])
def list_agents(system_id):
    """List all agents in system"""
    if system_id not in systems:
        return jsonify({"error": "System not found"}), 404
    
    system = systems[system_id]
    agents = []
    for name, agent in system.agents.items():
        agents.append({
            "name": name,
            "role": agent.role,
            "status": agent.state.status,
            "completed_tasks": len(agent.state.completed_tasks)
        })
    
    return jsonify({"agents": agents})


@app.route('/system/<system_id>/agent/add', methods=['POST'])
def add_agent(system_id):
    """Add an agent to the system"""
    if system_id not in systems:
        return jsonify({"error": "System not found"}), 404
    
    system = systems[system_id]
    data = request.json or {}
    agent_type = data.get('type', 'research')
    name = data.get('name', f'{agent_type.capitalize()}-{len(system.agents)}')
    
    if agent_type == 'research':
        agent = ResearchAgent(name)
    elif agent_type == 'analysis':
        agent = AnalysisAgent(name)
    elif agent_type == 'writing':
        agent = WriterAgent(name)
    elif agent_type == 'review':
        agent = CriticAgent(name)
    else:
        return jsonify({"error": f"Unknown agent type: {agent_type}"}), 400
    
    agent_id = system.register_agent(agent)
    
    return jsonify({
        "agent_id": agent_id,
        "name": name,
        "type": agent_type,
        "status": "created"
    })


@app.route('/research', methods=['POST'])
def run_research():
    """Run research pipeline"""
    data = request.json or {}
    topic = data.get('topic')
    
    if not topic:
        return jsonify({"error": "Topic is required"}), 400
    
    # Use existing system or create new one
    system_id = data.get('system_id')
    if system_id and system_id in systems:
        system = systems[system_id]
    else:
        system = MultiAgentSystem(f"Research-{topic[:20]}")
        system.create_standard_team()
        system_id = str(uuid.uuid4())[:8]
        systems[system_id] = system
    
    depth = data.get('depth', 'medium')
    
    try:
        result = system.run_research_pipeline(topic, depth=depth)
        
        # Extract key outputs
        writer_output = result.get('results', {}).get('step_3', {})
        critic_output = result.get('results', {}).get('step_4', {})
        
        return jsonify({
            "system_id": system_id,
            "topic": topic,
            "depth": depth,
            "status": "completed",
            "report": writer_output.get('content', ''),
            "word_count": writer_output.get('word_count', 0),
            "review_score": critic_output.get('overall_score', 0),
            "approved": critic_output.get('approved', False),
            "completed_at": datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/workflow/create', methods=['POST'])
def create_workflow():
    """Create a custom workflow"""
    data = request.json or {}
    system_id = data.get('system_id')
    
    if not system_id or system_id not in systems:
        return jsonify({"error": "Valid system_id is required"}), 400
    
    system = systems[system_id]
    name = data.get('name', 'Custom Workflow')
    steps = data.get('steps', [])
    
    if not steps:
        return jsonify({"error": "Workflow steps are required"}), 400
    
    try:
        workflow = system.create_workflow(name, steps)
        return jsonify({
            "workflow_id": workflow.workflow_id,
            "name": workflow.name,
            "steps_count": len(workflow.steps),
            "status": workflow.status
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/workflow/<workflow_id>/execute', methods=['POST'])
def execute_workflow(workflow_id):
    """Execute a workflow"""
    data = request.json or {}
    system_id = data.get('system_id')
    
    if not system_id or system_id not in systems:
        return jsonify({"error": "Valid system_id is required"}), 400
    
    system = systems[system_id]
    
    try:
        result = system.execute_workflow(workflow_id)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/agents/list', methods=['GET'])
def list_agent_types():
    """List available agent types"""
    return jsonify({
        "agent_types": [
            {"type": "research", "description": "Gathers and organizes information"},
            {"type": "analysis", "description": "Analyzes data and extracts insights"},
            {"type": "writing", "description": "Creates structured content"},
            {"type": "review", "description": "Reviews and provides feedback"}
        ]
    })


@app.route('/system/<system_id>/message', methods=['POST'])
def send_message(system_id):
    """Send a message between agents"""
    if system_id not in systems:
        return jsonify({"error": "System not found"}), 404
    
    data = request.json or {}
    sender = data.get('sender')
    recipient = data.get('recipient')
    content = data.get('content')
    msg_type = data.get('type', 'broadcast')
    
    if not all([sender, recipient, content]):
        return jsonify({"error": "sender, recipient, and content are required"}), 400
    
    system = systems[system_id]
    
    if sender not in system.agents:
        return jsonify({"error": f"Sender agent '{sender}' not found"}), 404
    
    agent = system.agents[sender]
    
    from agent_base import MessageType
    msg_enum = MessageType.BROADCAST if msg_type == 'broadcast' else MessageType.TASK
    
    agent.send_message(recipient, content, msg_enum)
    
    return jsonify({
        "status": "sent",
        "from": sender,
        "to": recipient,
        "type": msg_type
    })


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "systems_active": len(systems),
        "timestamp": datetime.now().isoformat()
    })


if __name__ == '__main__':
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║           Multi-Agent System API Server                      ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Endpoints:                                                  ║
    ║    GET  /                    - API info                      ║
    ║    GET  /health              - Health check                  ║
    ║    POST /system/create       - Create new system             ║
    ║    GET  /system/<id>/status  - Get system status             ║
    ║    POST /research            - Run research pipeline         ║
    ║    POST /workflow/create     - Create workflow               ║
    ║    POST /workflow/<id>/execute - Execute workflow            ║
    ╚══════════════════════════════════════════════════════════════╝
    
    Server running at: http://localhost:5000
    """)
    app.run(host='0.0.0.0', port=5000, debug=True)
