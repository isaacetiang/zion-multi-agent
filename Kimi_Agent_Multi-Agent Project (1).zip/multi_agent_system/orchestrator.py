"""
Orchestrator Module - Manages multi-agent system execution
"""
import json
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
from dataclasses import dataclass, field

from agent_base import Agent, Message, MessageType
from specialized_agents import (
    ResearchAgent, AnalysisAgent, WriterAgent, 
    CriticAgent, CoordinatorAgent
)


@dataclass
class WorkflowStep:
    """Represents a single step in a workflow"""
    step_id: str
    agent_name: str
    action: str
    params: Dict[str, Any]
    depends_on: List[str] = field(default_factory=list)
    status: str = "pending"  # pending, running, completed, failed
    result: Any = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


@dataclass
class Workflow:
    """Represents a complete workflow"""
    workflow_id: str
    name: str
    steps: List[WorkflowStep]
    status: str = "pending"
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class MultiAgentSystem:
    """
    Main orchestrator for the multi-agent system
    
    Manages:
    - Agent registration and lifecycle
    - Workflow execution
    - Inter-agent communication
    - Result aggregation
    """
    
    def __init__(self, name: str = "Multi-Agent System"):
        self.name = name
        self.agents: Dict[str, Agent] = {}
        self.workflows: Dict[str, Workflow] = {}
        self.execution_log: List[Dict] = []
        self.message_bus: List[Message] = []
        
        # Create default coordinator
        self.coordinator = CoordinatorAgent("Orchestrator")
        self.register_agent(self.coordinator)
    
    def register_agent(self, agent: Agent) -> str:
        """Register an agent with the system"""
        self.agents[agent.name] = agent
        
        # Register with coordinator
        if agent.name != self.coordinator.name:
            self.coordinator.register_peer(agent)
            agent.register_peer(self.coordinator)
        
        # Register with all other agents (full mesh)
        for other_name, other_agent in self.agents.items():
            if other_name != agent.name:
                agent.register_peer(other_agent)
                other_agent.register_peer(agent)
        
        self._log_event("agent_registered", {"agent": agent.name, "role": agent.role})
        return agent.agent_id
    
    def create_standard_team(self) -> Dict[str, Agent]:
        """Create a standard team of specialized agents"""
        team = {
            "researcher": ResearchAgent("Researcher"),
            "analyst": AnalysisAgent("Analyst"),
            "writer": WriterAgent("Writer"),
            "critic": CriticAgent("Critic")
        }
        
        for agent in team.values():
            self.register_agent(agent)
        
        print(f"✅ Created standard team with {len(team)} agents")
        return team
    
    def create_workflow(self, name: str, steps_config: List[Dict]) -> Workflow:
        """Create a new workflow"""
        workflow_id = f"wf_{len(self.workflows) + 1}_{datetime.now().strftime('%H%M%S')}"
        
        steps = []
        for i, config in enumerate(steps_config):
            step = WorkflowStep(
                step_id=f"step_{i+1}",
                agent_name=config.get("agent"),
                action=config.get("action"),
                params=config.get("params", {}),
                depends_on=config.get("depends_on", [])
            )
            steps.append(step)
        
        workflow = Workflow(
            workflow_id=workflow_id,
            name=name,
            steps=steps
        )
        
        self.workflows[workflow_id] = workflow
        self._log_event("workflow_created", {"id": workflow_id, "name": name, "steps": len(steps)})
        
        return workflow
    
    def execute_workflow(self, workflow_id: str) -> Dict[str, Any]:
        """Execute a workflow"""
        workflow = self.workflows.get(workflow_id)
        if not workflow:
            return {"error": f"Workflow {workflow_id} not found"}
        
        print(f"\n{'='*60}")
        print(f"🚀 Starting Workflow: {workflow.name}")
        print(f"{'='*60}")
        
        workflow.status = "running"
        results = {}
        
        for step in workflow.steps:
            # Check dependencies
            if step.depends_on:
                deps_satisfied = all(
                    results.get(dep, {}).get("status") == "completed"
                    for dep in step.depends_on
                )
                if not deps_satisfied:
                    step.status = "skipped"
                    continue
            
            # Execute step
            step.status = "running"
            step.started_at = datetime.now()
            
            print(f"\n▶️  Step {step.step_id}: {step.action} → {step.agent_name}")
            
            agent = self.agents.get(step.agent_name)
            if not agent:
                step.status = "failed"
                results[step.step_id] = {"error": f"Agent {step.agent_name} not found"}
                continue
            
            # Prepare parameters (substitute previous results)
            params = self._substitute_params(step.params, results)
            
            # Execute
            try:
                if step.action == "research":
                    result = agent.execute({
                        "topic": params.get("topic"),
                        "depth": params.get("depth", "medium")
                    })
                elif step.action == "analyze":
                    # Get data from previous step if not provided
                    data = params.get("data", [])
                    if not data and step.depends_on:
                        prev_result = results.get(step.depends_on[0], {})
                        if "findings" in prev_result:
                            data = prev_result["findings"]
                    
                    result = agent.execute({
                        "data": data,
                        "type": params.get("type", "general")
                    })
                elif step.action == "write":
                    # Build data from previous results
                    data = params.get("data", {})
                    if not data and step.depends_on:
                        for dep in step.depends_on:
                            dep_result = results.get(dep, {})
                            if "findings" in dep_result:
                                data["findings"] = dep_result["findings"]
                                data["topic"] = dep_result.get("topic", "")
                            if "insights" in dep_result:
                                data["analysis"] = dep_result
                    
                    result = agent.execute({
                        "content_type": params.get("content_type", "report"),
                        "data": data,
                        "style": params.get("style", "professional")
                    })
                elif step.action == "review":
                    content = params.get("content", "")
                    if not content and step.depends_on:
                        prev_result = results.get(step.depends_on[0], {})
                        content = prev_result.get("content", "")
                    
                    result = agent.execute({
                        "content": content,
                        "content_type": params.get("content_type", "report")
                    })
                else:
                    result = agent.execute(params)
                
                step.result = result
                step.status = "completed"
                results[step.step_id] = result
                
            except Exception as e:
                step.status = "failed"
                results[step.step_id] = {"error": str(e)}
                print(f"❌ Step {step.step_id} failed: {e}")
            
            step.completed_at = datetime.now()
        
        workflow.status = "completed"
        workflow.completed_at = datetime.now()
        
        print(f"\n{'='*60}")
        print(f"✅ Workflow '{workflow.name}' completed")
        print(f"{'='*60}")
        
        return {
            "workflow_id": workflow_id,
            "status": "completed",
            "results": results,
            "completed_at": workflow.completed_at.isoformat()
        }
    
    def _substitute_params(self, params: Dict, results: Dict) -> Dict:
        """Substitute parameter values with results from previous steps"""
        substituted = {}
        for key, value in params.items():
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                step_ref = value[2:-1]
                if step_ref in results:
                    substituted[key] = results[step_ref]
                else:
                    substituted[key] = value
            else:
                substituted[key] = value
        return substituted
    
    def run_research_pipeline(self, topic: str, depth: str = "medium") -> Dict[str, Any]:
        """
        Run a complete research pipeline:
        1. Research → 2. Analyze → 3. Write → 4. Review
        """
        # Ensure we have a team
        if len(self.agents) <= 1:  # Only coordinator
            self.create_standard_team()
        
        workflow_config = [
            {
                "agent": "Researcher",
                "action": "research",
                "params": {"topic": topic, "depth": depth}
            },
            {
                "agent": "Analyst",
                "action": "analyze",
                "params": {"type": "general"},
                "depends_on": ["step_1"]
            },
            {
                "agent": "Writer",
                "action": "write",
                "params": {"content_type": "report"},
                "depends_on": ["step_1", "step_2"]
            },
            {
                "agent": "Critic",
                "action": "review",
                "params": {"content_type": "report"},
                "depends_on": ["step_3"]
            }
        ]
        
        workflow = self.create_workflow(
            name=f"Research Pipeline: {topic}",
            steps_config=workflow_config
        )
        
        return self.execute_workflow(workflow.workflow_id)
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        agent_statuses = {
            name: agent.get_status() 
            for name, agent in self.agents.items()
        }
        
        return {
            "system_name": self.name,
            "agents_count": len(self.agents),
            "workflows_count": len(self.workflows),
            "agents": agent_statuses,
            "workflows": [
                {
                    "id": w.workflow_id,
                    "name": w.name,
                    "status": w.status,
                    "steps_count": len(w.steps)
                }
                for w in self.workflows.values()
            ]
        }
    
    def _log_event(self, event_type: str, data: Dict):
        """Log system event"""
        self.execution_log.append({
            "timestamp": datetime.now().isoformat(),
            "type": event_type,
            "data": data
        })
    
    def print_system_report(self):
        """Print a formatted system report"""
        status = self.get_system_status()
        
        print(f"\n{'='*60}")
        print(f"📊 {status['system_name']} - System Report")
        print(f"{'='*60}")
        
        print(f"\n🤖 Agents ({status['agents_count']}):")
        for name, agent_status in status['agents'].items():
            status_emoji = {
                "idle": "⏸️",
                "working": "⚙️",
                "completed": "✅",
                "error": "❌"
            }.get(agent_status['status'], "❓")
            print(f"  {status_emoji} {name} ({agent_status['role']}) - {agent_status['status']}")
        
        print(f"\n📋 Workflows ({status['workflows_count']}):")
        for wf in status['workflows']:
            status_emoji = {
                "pending": "⏳",
                "running": "🔄",
                "completed": "✅",
                "failed": "❌"
            }.get(wf['status'], "❓")
            print(f"  {status_emoji} {wf['name']} - {wf['status']} ({wf['steps_count']} steps)")
        
        print(f"\n{'='*60}\n")
