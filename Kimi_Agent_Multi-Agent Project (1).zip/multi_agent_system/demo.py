"""
Demo Script - Showcase Multi-Agent System Capabilities

This script demonstrates:
1. Creating a multi-agent team
2. Running collaborative workflows
3. Agent communication patterns
4. Result aggregation
"""
import json
from orchestrator import MultiAgentSystem
from specialized_agents import (
    ResearchAgent, AnalysisAgent, WriterAgent, CriticAgent
)
from agent_base import MessageType


def demo_basic_workflow():
    """Demo 1: Basic Research Pipeline"""
    print("\n" + "="*70)
    print("DEMO 1: Basic Research Pipeline")
    print("="*70)
    
    # Initialize system
    system = MultiAgentSystem("Research Team Alpha")
    
    # Create team
    system.create_standard_team()
    
    # Run research pipeline
    topic = "Artificial Intelligence in Healthcare"
    result = system.run_research_pipeline(topic, depth="medium")
    
    # Display results
    print("\n📄 FINAL REPORT:")
    print("-" * 50)
    
    # Get the writer's output
    writer_result = result.get("results", {}).get("step_3", {})
    if "content" in writer_result:
        print(writer_result["content"][:1500] + "...")
    
    # Get critic's review
    critic_result = result.get("results", {}).get("step_4", {})
    if critic_result:
        print(f"\n📊 Review Score: {critic_result.get('overall_score', 'N/A')}/100")
        print(f"✅ Approved: {critic_result.get('approved', False)}")
    
    # System status
    system.print_system_report()
    
    return system, result


def demo_custom_workflow():
    """Demo 2: Custom Multi-Step Workflow"""
    print("\n" + "="*70)
    print("DEMO 2: Custom Workflow - Market Analysis")
    print("="*70)
    
    system = MultiAgentSystem("Market Analysis Team")
    
    # Create custom team
    researcher = ResearchAgent("MarketResearcher")
    analyst = AnalysisAgent("DataAnalyst")
    writer = WriterAgent("ReportWriter")
    
    system.register_agent(researcher)
    system.register_agent(analyst)
    system.register_agent(writer)
    
    # Define custom workflow
    workflow_config = [
        {
            "agent": "MarketResearcher",
            "action": "research",
            "params": {"topic": "Electric Vehicle Market Trends 2024", "depth": "deep"}
        },
        {
            "agent": "DataAnalyst",
            "action": "analyze",
            "params": {"type": "trend"},
            "depends_on": ["step_1"]
        },
        {
            "agent": "ReportWriter",
            "action": "write",
            "params": {"content_type": "article", "style": "professional"},
            "depends_on": ["step_1", "step_2"]
        }
    ]
    
    workflow = system.create_workflow("EV Market Analysis", workflow_config)
    result = system.execute_workflow(workflow.workflow_id)
    
    print("\n📄 Generated Article:")
    print("-" * 50)
    
    writer_result = result.get("results", {}).get("step_3", {})
    if "content" in writer_result:
        print(writer_result["content"])
    
    return system, result


def demo_agent_communication():
    """Demo 3: Direct Agent Communication"""
    print("\n" + "="*70)
    print("DEMO 3: Direct Agent Communication")
    print("="*70)
    
    system = MultiAgentSystem("Communication Demo")
    
    # Create agents
    researcher = ResearchAgent("InfoGatherer")
    analyst = AnalysisAgent("PatternFinder")
    
    system.register_agent(researcher)
    system.register_agent(analyst)
    
    # Have researcher do some work first
    print("\n1. Researcher gathering information...")
    research_result = researcher.execute({
        "topic": "Climate Change Mitigation Strategies",
        "depth": "medium"
    })
    
    # Analyst sends query to researcher
    print("\n2. Analyst querying researcher for specific information...")
    analyst.send_message(
        recipient="InfoGatherer",
        content="climate adaptation",
        msg_type=MessageType.QUERY
    )
    
    # Show message exchange
    print(f"\n📨 Analyst's Outbox:")
    for msg in analyst.outbox:
        print(f"   → To {msg.recipient}: {msg.msg_type.value} - {msg.content}")
    
    print(f"\n📥 Researcher's Inbox:")
    for msg in researcher.inbox:
        print(f"   ← From {msg.sender}: {msg.msg_type.value}")
    
    # Show agent memory
    print(f"\n🧠 Researcher Memory ({len(researcher.memory)} entries):")
    for entry in researcher.memory[:3]:
        print(f"   - {entry['type']}: {entry['message']['msg_type']}")
    
    return system


def demo_parallel_tasks():
    """Demo 4: Parallel Task Execution"""
    print("\n" + "="*70)
    print("DEMO 4: Parallel Research Tasks")
    print("="*70)
    
    system = MultiAgentSystem("Parallel Research Team")
    
    # Create multiple researchers
    topics = [
        "Blockchain Technology",
        "Quantum Computing",
        "Renewable Energy"
    ]
    
    researchers = []
    for i, topic in enumerate(topics, 1):
        researcher = ResearchAgent(f"Researcher-{i}")
        system.register_agent(researcher)
        researchers.append((researcher, topic))
    
    # Execute research in parallel (simulated)
    print("\n🔄 Executing parallel research tasks...")
    results = []
    for researcher, topic in researchers:
        result = researcher.execute({"topic": topic, "depth": "shallow"})
        results.append((researcher.name, topic, result))
    
    # Display summary
    print("\n📊 Parallel Research Results:")
    print("-" * 50)
    for name, topic, result in results:
        findings_count = len(result.get("findings", []))
        print(f"  ✅ {name}: '{topic}' - {findings_count} findings")
    
    # Aggregate findings
    all_findings = []
    for _, _, result in results:
        all_findings.extend(result.get("findings", []))
    
    print(f"\n📚 Total findings aggregated: {len(all_findings)}")
    
    # Now analyze all findings together
    print("\n🔍 Sending aggregated data to analyst...")
    analyst = AnalysisAgent("Aggregator")
    system.register_agent(analyst)
    
    analysis = analyst.execute({
        "data": all_findings,
        "type": "comparative"
    })
    
    print("\n📊 Cross-Topic Analysis:")
    for insight in analysis.get("insights", []):
        print(f"  💡 {insight}")
    
    return system, results


def demo_full_report_generation():
    """Demo 5: Complete Report Generation with Iteration"""
    print("\n" + "="*70)
    print("DEMO 5: Iterative Report Generation")
    print("="*70)
    
    system = MultiAgentSystem("Report Generation Team")
    team = system.create_standard_team()
    
    topic = "Cybersecurity Best Practices for Remote Work"
    
    # Step 1: Research
    print(f"\n1️⃣ Research Phase")
    research_result = team["researcher"].execute({
        "topic": topic,
        "depth": "deep"
    })
    
    # Step 2: Analyze
    print(f"\n2️⃣ Analysis Phase")
    analysis_result = team["analyst"].execute({
        "data": research_result.get("findings", []),
        "type": "risk"
    })
    
    # Step 3: Write
    print(f"\n3️⃣ Writing Phase")
    write_data = {
        "topic": topic,
        "findings": research_result.get("findings", []),
        "analysis": analysis_result
    }
    
    writer_result = team["writer"].execute({
        "content_type": "report",
        "data": write_data,
        "style": "professional"
    })
    
    # Step 4: Review
    print(f"\n4️⃣ Review Phase")
    review_result = team["critic"].execute({
        "content": writer_result.get("content", ""),
        "content_type": "report"
    })
    
    # Display final report
    print("\n" + "="*70)
    print("FINAL REPORT")
    print("="*70)
    print(writer_result.get("content", ""))
    
    # Display review feedback
    print("\n" + "="*70)
    print("REVIEW FEEDBACK")
    print("="*70)
    print(f"Overall Score: {review_result.get('overall_score', 0)}/100")
    print(f"Status: {'✅ Approved' if review_result.get('approved') else '❌ Needs Revision'}")
    print("\nScores by Category:")
    for category, score in review_result.get('scores', {}).items():
        bar = "█" * int(score / 5)
        print(f"  {category.capitalize():15} {score:5.1f} {bar}")
    
    print("\nSuggestions:")
    for suggestion in review_result.get('suggestions', []):
        print(f"  • {suggestion}")
    
    return system, writer_result


def save_results_to_file(result: dict, filename: str):
    """Save results to JSON file"""
    filepath = f"/mnt/okcomputer/output/multi_agent_system/{filename}"
    with open(filepath, 'w') as f:
        json.dump(result, f, indent=2, default=str)
    print(f"\n💾 Results saved to: {filepath}")


def main():
    """Run all demos"""
    print("\n" + "🚀"*35)
    print("MULTI-AGENT SYSTEM DEMONSTRATION")
    print("🚀"*35)
    
    # Run demos
    try:
        # Demo 1: Basic workflow
        system1, result1 = demo_basic_workflow()
        
        # Demo 2: Custom workflow
        system2, result2 = demo_custom_workflow()
        
        # Demo 3: Agent communication
        system3 = demo_agent_communication()
        
        # Demo 4: Parallel tasks
        system4, result4 = demo_parallel_tasks()
        
        # Demo 5: Full report generation
        system5, result5 = demo_full_report_generation()
        
        # Save final report
        if result5 and isinstance(result5, dict):
            save_results_to_file(result5, "final_report.json")
        
        print("\n" + "="*70)
        print("✅ All demos completed successfully!")
        print("="*70)
        
    except Exception as e:
        print(f"\n❌ Error during demo: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
