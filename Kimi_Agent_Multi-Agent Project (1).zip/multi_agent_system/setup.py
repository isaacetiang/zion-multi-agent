"""
Setup script for multi-agent system package
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="multi-agent-system",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A flexible framework for building collaborative multi-agent systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/multi-agent-system",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Core has no dependencies
    ],
    extras_require={
        "viz": ["matplotlib>=3.5.0", "numpy>=1.21.0"],
        "web": ["flask>=2.0.0", "fastapi>=0.95.0", "uvicorn>=0.20.0"],
        "dashboard": ["streamlit>=1.20.0"],
        "dev": ["pytest>=7.0.0", "black>=22.0.0", "flake8>=5.0.0"],
        "all": [
            "matplotlib>=3.5.0",
            "numpy>=1.21.0",
            "flask>=2.0.0",
            "fastapi>=0.95.0",
            "uvicorn>=0.20.0",
            "streamlit>=1.20.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "multi-agent=cli:main",
        ],
    },
)
