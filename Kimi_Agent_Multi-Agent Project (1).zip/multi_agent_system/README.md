# Multi-Agent System Framework

A flexible, extensible Python framework for building collaborative multi-agent systems. This framework enables the creation of specialized agents that can communicate, coordinate, and work together to accomplish complex tasks.

## Features

- **Modular Architecture**: Easy to extend with new agent types
- **Inter-Agent Communication**: Rich messaging system with multiple message types
- **Workflow Orchestration**: Define and execute complex multi-step workflows
- **State Management**: Track agent states and task progress
- **Visualization**: Visualize agent networks, workflows, and message flows
- **Zero External Dependencies**: Core functionality uses only Python standard library

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    MultiAgentSystem                         │
│                    (Orchestrator)                           │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Research │  │ Analysis │  │  Writer  │  │  Critic  │   │
│  │  Agent   │  │  Agent   │  │  Agent   │  │  Agent   │   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘   │
│       │             │             │             │          │
│       └─────────────┴─────────────┴─────────────┘          │
│                     Message Bus                             │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

### 1. Basic Usage

```python
from orchestrator import MultiAgentSystem

# Create system
system = MultiAgentSystem("My Team")

# Create standard team (Researcher, Analyst, Writer, Critic)
team = system.create_standard_team()

# Run research pipeline
result = system.run_research_pipeline(
    topic="Artificial Intelligence",
    depth="medium"
)

# Print final report
print(result["results"]["step_3"]["content"])
```

### 2. Custom Workflow

```python
from orchestrator import MultiAgentSystem

system = MultiAgentSystem("Custom Team")
system.create_standard_team()

# Define custom workflow
workflow_config = [
    {
        "agent": "Researcher",
        "action": "research",
        "params": {"topic": "Quantum Computing", "depth": "deep"}
    },
    {
        "agent": "Analyst",
        "action": "analyze",
        "params": {"type": "trend"},
        "depends_on": ["step_1"]
    },
    {
        "agent": "Writer",
        "action": "write",
        "params": {"content_type": "report"},
        "depends_on": ["step_1", "step_2"]
    }
]

# Create and execute workflow
workflow = system.create_workflow("Quantum Report", workflow_config)
result = system.execute_workflow(workflow.workflow_id)
```

### 3. Direct Agent Communication

```python
from specialized_agents import ResearchAgent, AnalysisAgent

# Create agents
researcher = ResearchAgent("Researcher")
analyst = AnalysisAgent("Analyst")

# Register as peers
researcher.register_peer(analyst)
analyst.register_peer(researcher)

# Send message
analyst.send_message(
    recipient="Researcher",
    content="What are the latest findings?",
    msg_type=MessageType.QUERY
)

# Check inbox
for msg in researcher.inbox:
    print(f"From {msg.sender}: {msg.content}")
```

## Agent Types

### ResearchAgent
- **Purpose**: Gathers and organizes information
- **Capabilities**: Search simulation, fact extraction, source organization
- **Execute Params**: `topic`, `depth` (shallow/medium/deep)

### AnalysisAgent
- **Purpose**: Processes and analyzes information
- **Capabilities**: Pattern recognition, trend analysis, insight generation
- **Execute Params**: `data`, `type` (trend/comparative/risk/general)

### WriterAgent
- **Purpose**: Creates well-structured content
- **Capabilities**: Report writing, summarization, style adaptation
- **Execute Params**: `content_type` (report/summary/article), `data`, `style`

### CriticAgent
- **Purpose**: Reviews and provides feedback
- **Capabilities**: Quality assessment, error detection, improvement suggestions
- **Execute Params**: `content`, `content_type`

### CoordinatorAgent
- **Purpose**: Manages workflow and task distribution
- **Capabilities**: Task decomposition, agent coordination, progress monitoring

## Message Types

| Type | Purpose |
|------|---------|
| `TASK` | Assign work to an agent |
| `RESULT` | Return task results |
| `QUERY` | Request information |
| `RESPONSE` | Reply to a query |
| `BROADCAST` | Send to all peers |
| `STATUS` | Status updates |

## Workflow System

Workflows define sequences of agent actions with dependencies:

```python
workflow_config = [
    {
        "agent": "Researcher",
        "action": "research",
        "params": {"topic": "Climate Change"}
    },
    {
        "agent": "Analyst",
        "action": "analyze",
        "params": {"type": "trend"},
        "depends_on": ["step_1"]  # Waits for step_1
    },
    {
        "agent": "Writer",
        "action": "write",
        "params": {"content_type": "report"},
        "depends_on": ["step_1", "step_2"]  # Waits for both
    }
]
```

## Visualization

```python
from visualization import AgentVisualizer

viz = AgentVisualizer(system)

# Visualize agent network
viz.visualize_agent_network("network.png")

# Visualize workflow
viz.visualize_workflow("wf_1", "workflow.png")

# Visualize message flow
viz.visualize_message_flow("messages.png")

# Generate text report
print(viz.generate_system_report())
```

## Running Demos

```bash
# Run all demos
python demo.py

# Individual demos
python -c "from demo import demo_basic_workflow; demo_basic_workflow()"
python -c "from demo import demo_custom_workflow; demo_custom_workflow()"
python -c "from demo import demo_agent_communication; demo_agent_communication()"
python -c "from demo import demo_parallel_tasks; demo_parallel_tasks()"
```

## Creating Custom Agents

```python
from agent_base import Agent, Message, MessageType

class MyCustomAgent(Agent):
    def __init__(self, name: str):
        super().__init__(
            name=name,
            role="custom",
            description="My custom agent"
        )
    
    def execute(self, task: dict) -> dict:
        # Implement your logic
        return {"result": "Task completed"}
    
    def _handle_task(self, message: Message):
        # Custom task handling
        result = self.execute(message.content)
        self.send_message(
            recipient=message.sender,
            content=result,
            msg_type=MessageType.RESULT
        )
```

## Project Structure

```
multi_agent_system/
├── __init__.py              # Package initialization
├── agent_base.py            # Base Agent class and message types
├── specialized_agents.py    # Concrete agent implementations
├── orchestrator.py          # MultiAgentSystem and workflow management
├── visualization.py         # Visualization utilities
├── demo.py                  # Demonstration scripts
├── requirements.txt         # Dependencies
└── README.md               # This file
```

## Advanced Features

### State Management
```python
# Check agent status
status = agent.get_status()
print(status)

# Update state
agent.update_state(status="working", current_task="research")
```

### Memory System
```python
# Access agent memory
for entry in agent.memory:
    print(entry["type"], entry["message"])
```

### Message History
```python
# Check message boxes
print(f"Inbox: {len(agent.inbox)}")
print(f"Outbox: {len(agent.outbox)}")
```

## Use Cases

1. **Automated Research**: Multi-step research with analysis and reporting
2. **Content Generation**: Collaborative writing with review cycles
3. **Data Processing**: Parallel data analysis with aggregation
4. **Decision Support**: Multi-perspective analysis and recommendation
5. **Workflow Automation**: Complex business process automation

## Extending the Framework

### Add New Message Types
```python
class MessageType(Enum):
    # ... existing types
    CUSTOM = "custom"
```

### Add New Agent Capabilities
```python
def execute(self, task: dict) -> dict:
    action = task.get("action")
    if action == "new_capability":
        return self._new_capability(task)
    # ... existing actions
```

### Integrate External APIs
```python
def _simulate_research(self, topic: str, depth: str) -> list:
    # Replace with actual API calls
    # return search_api.query(topic, depth)
    pass
```

## License

MIT License - Feel free to use and modify!

## Contributing

Contributions welcome! Areas for enhancement:
- Additional agent types
- Real API integrations
- Web-based dashboard
- Persistent storage
- Distributed execution
