# Deployment Guide - Multi-Agent System

This guide covers all deployment options for the Multi-Agent System.

## Table of Contents
1. [Local Development](#1-local-development)
2. [Python Package Installation](#2-python-package-installation)
3. [Docker Deployment](#3-docker-deployment)
4. [REST API Server](#4-rest-api-server)
5. [CLI Tool](#5-cli-tool)
6. [Streamlit Dashboard](#6-streamlit-dashboard)
7. [Cloud Deployment](#7-cloud-deployment)

---

## 1. Local Development

### Prerequisites
- Python 3.8+
- pip

### Setup
```bash
# Clone/navigate to project
cd multi_agent_system

# Install in development mode
pip install -e .

# Or install with dependencies
pip install -e ".[all]"

# Run demo
python demo.py

# Run simple example
python example_simple.py
```

---

## 2. Python Package Installation

### Install from Source
```bash
# Basic install (no dependencies)
pip install .

# With visualization support
pip install ".[viz]"

# With web API support
pip install ".[web]"

# With dashboard
pip install ".[dashboard]"

# Everything
pip install ".[all]"
```

### Use as Library
```python
from multi_agent_system import MultiAgentSystem, ResearchAgent

system = MultiAgentSystem("My App")
system.create_standard_team()
result = system.run_research_pipeline("Your Topic")
```

---

## 3. Docker Deployment

### Build Image
```bash
cd multi_agent_system

# Build
docker build -t multi-agent-system .

# Run demo
docker run multi-agent-system

# Run API server
docker run -p 5000:5000 multi-agent-system python api.py

# Interactive shell
docker run -it multi-agent-system bash
```

### Docker Compose
```yaml
version: '3.8'

services:
  multi-agent-api:
    build: .
    ports:
      - "5000:5000"
    command: python api.py
    environment:
      - FLASK_ENV=production
  
  multi-agent-dashboard:
    build: .
    ports:
      - "8501:8501"
    command: streamlit run dashboard.py --server.port 8501
```

Run: `docker-compose up`

---

## 4. REST API Server

### Start Server
```bash
# Install dependencies
pip install flask flask-cors

# Start API server
python api.py
```

Server runs at `http://localhost:5000`

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | API info |
| `/health` | GET | Health check |
| `/system/create` | POST | Create new system |
| `/system/<id>/status` | GET | Get system status |
| `/system/<id>/agents` | GET | List agents |
| `/system/<id>/agent/add` | POST | Add agent |
| `/research` | POST | Run research pipeline |
| `/workflow/create` | POST | Create workflow |
| `/workflow/<id>/execute` | POST | Execute workflow |

### Example Usage
```bash
# Create system
curl -X POST http://localhost:5000/system/create \
  -H "Content-Type: application/json" \
  -d '{"name": "My Team", "create_team": true}'

# Run research
curl -X POST http://localhost:5000/research \
  -H "Content-Type: application/json" \
  -d '{"topic": "Artificial Intelligence", "depth": "medium"}'
```

### Python Client
```python
import requests

# Create system
response = requests.post("http://localhost:5000/system/create", json={
    "name": "API Test",
    "create_team": True
})
system_id = response.json()["system_id"]

# Run research
result = requests.post("http://localhost:5000/research", json={
    "system_id": system_id,
    "topic": "Climate Change",
    "depth": "deep"
})
print(result.json()["report"])
```

---

## 5. CLI Tool

### Installation
```bash
pip install -e .
```

### Usage

```bash
# Research command
multi-agent research "Your Topic" --depth deep --output result.json

# Create system
multi-agent system create --name "My Team" --with-team

# Interactive mode
multi-agent interactive

# Run workflow from config
multi-agent workflow --config workflow.json --output result.json
```

### Direct Usage
```bash
# Without installation
python cli.py research "Artificial Intelligence" --depth medium

# Interactive mode
python cli.py interactive
```

---

## 6. Streamlit Dashboard

### Installation
```bash
pip install streamlit
```

### Run Dashboard
```bash
streamlit run dashboard.py
```

Access at `http://localhost:8501`

### Features
- 🔬 Research pipeline with UI
- 👥 Agent management
- 📋 Workflow visualization
- 📊 Real-time status monitoring

---

## 7. Cloud Deployment

### Heroku

1. Create `Procfile`:
```
web: python api.py
```

2. Create `runtime.txt`:
```
python-3.11.0
```

3. Deploy:
```bash
heroku create your-app-name
git push heroku main
```

### AWS Elastic Beanstalk

1. Create `.ebextensions/python.config`:
```yaml
option_settings:
  aws:elasticbeanstalk:container:python:
    WSGIPath: api:app
```

2. Deploy:
```bash
eb init -p python-3.11 multi-agent-system
eb create multi-agent-env
eb open
```

### Google Cloud Run

1. Build and push:
```bash
gcloud builds submit --tag gcr.io/PROJECT-ID/multi-agent-system
```

2. Deploy:
```bash
gcloud run deploy --image gcr.io/PROJECT-ID/multi-agent-system --platform managed
```

### Azure Container Instances

```bash
# Create resource group
az group create --name multi-agent-rg --location eastus

# Create container
az container create \
  --resource-group multi-agent-rg \
  --name multi-agent-system \
  --image multi-agent-system \
  --ports 5000
```

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `FLASK_ENV` | Flask environment | `development` |
| `FLASK_PORT` | API server port | `5000` |
| `STREAMLIT_PORT` | Dashboard port | `8501` |

---

## Production Checklist

- [ ] Use production WSGI server (gunicorn, uWSGI)
- [ ] Enable authentication/authorization
- [ ] Set up logging
- [ ] Configure monitoring
- [ ] Use environment variables for config
- [ ] Set up SSL/TLS
- [ ] Implement rate limiting
- [ ] Add health checks

### Production WSGI
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 api:app
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Port already in use | Change port: `python api.py` then edit port |
| Module not found | Run `pip install -e .` |
| Import errors | Check Python version (3.8+) |
| Docker build fails | Check Dockerfile syntax |

---

## Quick Reference

```bash
# Development
pip install -e ".[all]"
python demo.py

# API Server
python api.py

# Dashboard
streamlit run dashboard.py

# CLI
python cli.py research "Topic" --depth deep

# Docker
docker build -t mas .
docker run -p 5000:5000 mas python api.py
```
