"""
Command Line Interface for Multi-Agent System

Usage:
    python cli.py research "Your Topic" --depth deep
    python cli.py system create --name "My Team"
    python cli.py workflow run --config workflow.json
"""
import argparse
import json
import sys
from datetime import datetime

from orchestrator import MultiAgentSystem
from specialized_agents import ResearchAgent, AnalysisAgent, WriterAgent, CriticAgent


def cmd_research(args):
    """Run research command"""
    print(f"🔬 Researching: {args.topic}")
    print(f"   Depth: {args.depth}")
    print("-" * 50)
    
    system = MultiAgentSystem("CLI Research")
    system.create_standard_team()
    
    result = system.run_research_pipeline(args.topic, depth=args.depth)
    
    # Output
    writer_output = result.get('results', {}).get('step_3', {})
    critic_output = result.get('results', {}).get('step_4', {})
    
    if args.output:
        output_data = {
            "topic": args.topic,
            "report": writer_output.get('content', ''),
            "review_score": critic_output.get('overall_score', 0),
            "approved": critic_output.get('approved', False),
            "generated_at": datetime.now().isoformat()
        }
        with open(args.output, 'w') as f:
            json.dump(output_data, f, indent=2)
        print(f"\n💾 Results saved to: {args.output}")
    else:
        print("\n" + "="*60)
        print("REPORT")
        print("="*60)
        print(writer_output.get('content', ''))
        print("\n" + "="*60)
        print(f"Review Score: {critic_output.get('overall_score', 0)}/100")
        print(f"Approved: {'✅' if critic_output.get('approved') else '❌'}")


def cmd_system_create(args):
    """Create a new system"""
    system = MultiAgentSystem(args.name)
    
    if args.with_team:
        system.create_standard_team()
        print(f"✅ Created system '{args.name}' with standard team")
    else:
        print(f"✅ Created empty system '{args.name}'")
    
    print(f"   Agents: {len(system.agents)}")
    
    if args.save:
        # Save system state (simplified)
        print(f"💾 System state would be saved to: {args.save}")


def cmd_system_status(args):
    """Show system status"""
    system = MultiAgentSystem(args.name)
    system.create_standard_team()
    
    status = system.get_system_status()
    
    print("\n" + "="*60)
    print(f"System: {status['system_name']}")
    print("="*60)
    
    print(f"\nAgents ({status['agents_count']}):")
    for name, agent in status['agents'].items():
        print(f"  • {name} ({agent['role']}) - {agent['status']}")
    
    print(f"\nWorkflows ({status['workflows_count']}):")
    for wf in status['workflows']:
        print(f"  • {wf['name']} - {wf['status']}")


def cmd_workflow_run(args):
    """Run a workflow from config file"""
    with open(args.config, 'r') as f:
        config = json.load(f)
    
    system = MultiAgentSystem(config.get('name', 'Workflow System'))
    system.create_standard_team()
    
    workflow = system.create_workflow(
        name=config.get('workflow_name', 'Custom Workflow'),
        steps_config=config.get('steps', [])
    )
    
    print(f"🚀 Running workflow: {workflow.name}")
    result = system.execute_workflow(workflow.workflow_id)
    
    print("\n✅ Workflow completed!")
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(result, f, indent=2, default=str)
        print(f"💾 Results saved to: {args.output}")


def cmd_interactive(args):
    """Interactive mode"""
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║           Multi-Agent System - Interactive Mode              ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Commands:                                                   ║
    ║    research <topic>  - Run research on topic                 ║
    ║    status            - Show system status                    ║
    ║    agents            - List agents                           ║
    ║    quit              - Exit                                  ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    system = MultiAgentSystem("Interactive")
    system.create_standard_team()
    
    while True:
        try:
            cmd = input("\nmas> ").strip().split()
            
            if not cmd:
                continue
            
            if cmd[0] == 'quit':
                print("Goodbye!")
                break
            
            elif cmd[0] == 'research':
                topic = ' '.join(cmd[1:])
                if not topic:
                    print("Usage: research <topic>")
                    continue
                
                print(f"🔬 Researching: {topic}")
                result = system.run_research_pipeline(topic)
                writer_output = result.get('results', {}).get('step_3', {})
                print("\n" + writer_output.get('content', '')[:500] + "...")
            
            elif cmd[0] == 'status':
                status = system.get_system_status()
                print(f"\nSystem: {status['system_name']}")
                print(f"Agents: {status['agents_count']}")
                print(f"Workflows: {status['workflows_count']}")
            
            elif cmd[0] == 'agents':
                for name, agent in system.agents.items():
                    print(f"  • {name} ({agent.role}) - {agent.state.status}")
            
            else:
                print(f"Unknown command: {cmd[0]}")
        
        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except Exception as e:
            print(f"Error: {e}")


def main():
    parser = argparse.ArgumentParser(
        description='Multi-Agent System CLI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cli.py research "Artificial Intelligence" --depth deep
  python cli.py system create --name "My Team" --with-team
  python cli.py interactive
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Research command
    research_parser = subparsers.add_parser('research', help='Run research on a topic')
    research_parser.add_argument('topic', help='Topic to research')
    research_parser.add_argument('--depth', choices=['shallow', 'medium', 'deep'],
                                default='medium', help='Research depth')
    research_parser.add_argument('--output', '-o', help='Output file (JSON)')
    
    # System commands
    system_parser = subparsers.add_parser('system', help='System management')
    system_subparsers = system_parser.add_subparsers(dest='system_cmd')
    
    create_parser = system_subparsers.add_parser('create', help='Create a system')
    create_parser.add_argument('--name', default='New System', help='System name')
    create_parser.add_argument('--with-team', action='store_true', help='Create with standard team')
    create_parser.add_argument('--save', help='Save system state to file')
    
    status_parser = system_subparsers.add_parser('status', help='Show system status')
    status_parser.add_argument('--name', default='System', help='System name')
    
    # Workflow command
    workflow_parser = subparsers.add_parser('workflow', help='Workflow management')
    workflow_parser.add_argument('--config', '-c', required=True, help='Workflow config file')
    workflow_parser.add_argument('--output', '-o', help='Output file')
    
    # Interactive mode
    interactive_parser = subparsers.add_parser('interactive', help='Interactive mode')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    if args.command == 'research':
        cmd_research(args)
    elif args.command == 'system':
        if args.system_cmd == 'create':
            cmd_system_create(args)
        elif args.system_cmd == 'status':
            cmd_system_status(args)
        else:
            system_parser.print_help()
    elif args.command == 'workflow':
        cmd_workflow_run(args)
    elif args.command == 'interactive':
        cmd_interactive(args)


if __name__ == '__main__':
    main()
