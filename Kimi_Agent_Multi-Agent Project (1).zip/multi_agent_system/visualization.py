"""
Visualization Module - Visualize agent interactions and system state
"""
import json
from typing import Dict, List, Any
from datetime import datetime
from collections import defaultdict

try:
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    import numpy as np
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    print("Matplotlib not available. Using text-based visualization.")


class AgentVisualizer:
    """Visualize agent interactions and system state"""
    
    def __init__(self, system):
        self.system = system
        self.colors = {
            "research": "#4A90D9",
            "analysis": "#5CB85C",
            "writing": "#F0AD4E",
            "review": "#D9534F",
            "coordination": "#9B59B6",
            "default": "#95A5A6"
        }
        self.status_icons = {
            "idle": "⏸️",
            "working": "⚙️",
            "completed": "✅",
            "waiting": "⏳",
            "error": "❌"
        }
    
    def visualize_agent_network(self, save_path: str = None):
        """Visualize agent communication network"""
        if not MATPLOTLIB_AVAILABLE:
            return self._text_network_visualization()
        
        fig, ax = plt.subplots(figsize=(12, 10))
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 10)
        ax.set_aspect('equal')
        ax.axis('off')
        
        # Position agents in a circle
        agents = list(self.system.agents.values())
        n_agents = len(agents)
        
        if n_agents == 0:
            ax.text(5, 5, "No agents in system", ha='center', va='center', fontsize=14)
            plt.tight_layout()
            if save_path:
                plt.savefig(save_path, dpi=150, bbox_inches='tight')
            plt.show()
            return
        
        center_x, center_y = 5, 5
        radius = 3.5
        
        positions = {}
        for i, agent in enumerate(agents):
            angle = 2 * 3.14159 * i / n_agents - 3.14159 / 2
            x = center_x + radius * np.cos(angle)
            y = center_y + radius * np.sin(angle)
            positions[agent.name] = (x, y)
            
            # Draw agent node
            color = self.colors.get(agent.role, self.colors["default"])
            
            # Agent circle
            circle = plt.Circle((x, y), 0.6, color=color, alpha=0.8, zorder=3)
            ax.add_patch(circle)
            
            # Agent name
            ax.text(x, y, agent.name[:8], ha='center', va='center', 
                   fontsize=8, fontweight='bold', color='white', zorder=4)
            
            # Role label
            ax.text(x, y - 0.9, agent.role, ha='center', va='top', 
                   fontsize=7, style='italic', color='#555')
            
            # Status indicator
            status_color = {"idle": "#95A5A6", "working": "#F39C12", 
                          "completed": "#27AE60", "error": "#E74C3C"}
            status_circle = plt.Circle((x + 0.4, y + 0.4), 0.15, 
                                       color=status_color.get(agent.state.status, "#95A5A6"),
                                       zorder=5)
            ax.add_patch(status_circle)
        
        # Draw communication edges
        for agent in agents:
            for peer_name in agent.peers:
                if peer_name in positions:
                    x1, y1 = positions[agent.name]
                    x2, y2 = positions[peer_name]
                    
                    # Draw arrow
                    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                               arrowprops=dict(arrowstyle="->", color="#BDC3C7", 
                                             alpha=0.5, lw=1))
        
        # Title
        ax.text(5, 9.5, f"Agent Communication Network: {self.system.name}", 
               ha='center', va='top', fontsize=14, fontweight='bold')
        
        # Legend
        legend_y = 0.5
        for i, (role, color) in enumerate(self.colors.items()):
            if role != "default":
                ax.add_patch(plt.Rectangle((0.5 + i*1.8, legend_y), 0.3, 0.3, 
                                          color=color, alpha=0.8))
                ax.text(0.9 + i*1.8, legend_y + 0.15, role, 
                       fontsize=8, va='center')
        
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
    
    def _text_network_visualization(self):
        """Text-based network visualization"""
        print("\n" + "="*60)
        print("AGENT COMMUNICATION NETWORK")
        print("="*60)
        
        for name, agent in self.system.agents.items():
            color = self.colors.get(agent.role, self.colors["default"])
            status_icon = self.status_icons.get(agent.state.status, "❓")
            
            print(f"\n{status_icon} {name} ({agent.role})")
            print(f"   Status: {agent.state.status}")
            print(f"   Peers: {', '.join(agent.peers.keys()) if agent.peers else 'None'}")
            print(f"   Tasks: {len(agent.state.completed_tasks)} completed")
    
    def visualize_workflow(self, workflow_id: str, save_path: str = None):
        """Visualize workflow execution"""
        workflow = self.system.workflows.get(workflow_id)
        if not workflow:
            print(f"Workflow {workflow_id} not found")
            return
        
        if not MATPLOTLIB_AVAILABLE:
            return self._text_workflow_visualization(workflow)
        
        fig, ax = plt.subplots(figsize=(14, 8))
        ax.set_xlim(0, len(workflow.steps) + 1)
        ax.set_ylim(0, 3)
        ax.axis('off')
        
        # Title
        ax.text(len(workflow.steps)/2 + 0.5, 2.8, f"Workflow: {workflow.name}", 
               ha='center', fontsize=14, fontweight='bold')
        ax.text(len(workflow.steps)/2 + 0.5, 2.5, f"Status: {workflow.status}", 
               ha='center', fontsize=10, style='italic')
        
        # Draw steps
        status_colors = {
            "pending": "#BDC3C7",
            "running": "#F39C12",
            "completed": "#27AE60",
            "failed": "#E74C3C",
            "skipped": "#95A5A6"
        }
        
        for i, step in enumerate(workflow.steps):
            x = i + 1
            
            # Step box
            color = status_colors.get(step.status, "#BDC3C7")
            rect = FancyBboxPatch((x - 0.4, 1), 0.8, 1, 
                                  boxstyle="round,pad=0.05",
                                  facecolor=color, edgecolor='black', linewidth=1)
            ax.add_patch(rect)
            
            # Step info
            ax.text(x, 1.7, step.step_id, ha='center', va='center', 
                   fontsize=10, fontweight='bold', color='white')
            ax.text(x, 1.4, step.agent_name[:10], ha='center', va='center', 
                   fontsize=8, color='white')
            ax.text(x, 1.1, step.action[:12], ha='center', va='center', 
                   fontsize=7, color='white')
            
            # Dependencies
            if step.depends_on:
                for dep in step.depends_on:
                    dep_idx = int(dep.split('_')[1]) - 1
                    ax.annotate("", xy=(x - 0.4, 1.5), xytext=(dep_idx + 1 + 0.4, 1.5),
                               arrowprops=dict(arrowstyle="->", color="#3498DB", lw=2))
            elif i > 0:
                # Sequential flow
                ax.annotate("", xy=(x - 0.4, 1.5), xytext=(x - 0.6, 1.5),
                           arrowprops=dict(arrowstyle="->", color="#7F8C8D", lw=1.5))
        
        # Legend
        legend_items = [
            ("Pending", "#BDC3C7"),
            ("Running", "#F39C12"),
            ("Completed", "#27AE60"),
            ("Failed", "#E74C3C")
        ]
        
        for i, (label, color) in enumerate(legend_items):
            ax.add_patch(plt.Rectangle((0.5 + i*2, 0.2), 0.3, 0.2, color=color))
            ax.text(0.9 + i*2, 0.3, label, fontsize=8, va='center')
        
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
    
    def _text_workflow_visualization(self, workflow):
        """Text-based workflow visualization"""
        print("\n" + "="*60)
        print(f"WORKFLOW: {workflow.name}")
        print("="*60)
        
        status_icons = {
            "pending": "⏳",
            "running": "🔄",
            "completed": "✅",
            "failed": "❌",
            "skipped": "⏭️"
        }
        
        for step in workflow.steps:
            icon = status_icons.get(step.status, "❓")
            deps = f" ← {', '.join(step.depends_on)}" if step.depends_on else ""
            print(f"\n{icon} {step.step_id}: {step.action} ({step.agent_name}){deps}")
            if step.result:
                print(f"   Result: {type(step.result).__name__}")
    
    def visualize_message_flow(self, save_path: str = None):
        """Visualize message flow between agents"""
        if not MATPLOTLIB_AVAILABLE:
            return self._text_message_visualization()
        
        # Collect message statistics
        message_stats = defaultdict(lambda: defaultdict(int))
        message_types = set()
        
        for agent in self.system.agents.values():
            for msg in agent.outbox:
                message_stats[msg.sender][msg.recipient] += 1
                message_types.add(msg.msg_type.value)
        
        if not message_stats:
            print("No messages to visualize")
            return
        
        agents = list(self.system.agents.keys())
        n = len(agents)
        
        fig, ax = plt.subplots(figsize=(10, 10))
        
        # Create matrix
        matrix = [[0]*n for _ in range(n)]
        for i, sender in enumerate(agents):
            for j, recipient in enumerate(agents):
                matrix[i][j] = message_stats[sender][recipient]
        
        # Plot heatmap
        im = ax.imshow(matrix, cmap='YlOrRd')
        
        # Labels
        ax.set_xticks(range(n))
        ax.set_yticks(range(n))
        ax.set_xticklabels(agents, rotation=45, ha='right')
        ax.set_yticklabels(agents)
        
        # Add values
        for i in range(n):
            for j in range(n):
                text = ax.text(j, i, matrix[i][j], ha='center', va='center', 
                              color='white' if matrix[i][j] > max(map(max, matrix))/2 else 'black')
        
        ax.set_title(f"Message Flow Matrix: {self.system.name}", fontsize=14, fontweight='bold')
        ax.set_xlabel("Recipient", fontsize=12)
        ax.set_ylabel("Sender", fontsize=12)
        
        plt.colorbar(im, ax=ax, label='Message Count')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
    
    def _text_message_visualization(self):
        """Text-based message visualization"""
        print("\n" + "="*60)
        print("MESSAGE FLOW SUMMARY")
        print("="*60)
        
        message_stats = defaultdict(lambda: defaultdict(int))
        
        for agent in self.system.agents.values():
            for msg in agent.outbox:
                message_stats[msg.sender][msg.recipient] += 1
        
        for sender in message_stats:
            print(f"\n📤 {sender} sent:")
            for recipient, count in message_stats[sender].items():
                print(f"   → {recipient}: {count} messages")
    
    def generate_system_report(self) -> str:
        """Generate a comprehensive text report"""
        lines = []
        lines.append("="*70)
        lines.append(f"MULTI-AGENT SYSTEM REPORT: {self.system.name}")
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("="*70)
        
        # Agent Summary
        lines.append("\n📊 AGENT SUMMARY")
        lines.append("-"*70)
        lines.append(f"Total Agents: {len(self.system.agents)}")
        lines.append("")
        
        for name, agent in self.system.agents.items():
            lines.append(f"\n🤖 {name}")
            lines.append(f"   Role: {agent.role}")
            lines.append(f"   Status: {agent.state.status}")
            lines.append(f"   Completed Tasks: {len(agent.state.completed_tasks)}")
            lines.append(f"   Inbox: {len(agent.inbox)} | Outbox: {len(agent.outbox)}")
            lines.append(f"   Peers: {', '.join(agent.peers.keys())}")
        
        # Workflow Summary
        lines.append("\n\n📋 WORKFLOW SUMMARY")
        lines.append("-"*70)
        lines.append(f"Total Workflows: {len(self.system.workflows)}")
        lines.append("")
        
        for wf_id, workflow in self.system.workflows.items():
            lines.append(f"\n📁 {workflow.name} ({wf_id})")
            lines.append(f"   Status: {workflow.status}")
            lines.append(f"   Steps: {len(workflow.steps)}")
            lines.append(f"   Created: {workflow.created_at.strftime('%Y-%m-%d %H:%M')}")
            
            completed = sum(1 for s in workflow.steps if s.status == "completed")
            lines.append(f"   Progress: {completed}/{len(workflow.steps)} steps completed")
        
        # Message Statistics
        lines.append("\n\n📨 MESSAGE STATISTICS")
        lines.append("-"*70)
        
        total_messages = sum(len(a.outbox) for a in self.system.agents.values())
        lines.append(f"Total Messages Sent: {total_messages}")
        
        message_types = defaultdict(int)
        for agent in self.system.agents.values():
            for msg in agent.outbox:
                message_types[msg.msg_type.value] += 1
        
        lines.append("\nBy Type:")
        for msg_type, count in sorted(message_types.items()):
            lines.append(f"   {msg_type}: {count}")
        
        lines.append("\n" + "="*70)
        
        return "\n".join(lines)
    
    def save_report(self, filepath: str):
        """Save system report to file"""
        report = self.generate_system_report()
        with open(filepath, 'w') as f:
            f.write(report)
        print(f"Report saved to: {filepath}")


def create_interactive_dashboard(system, port: int = 8080):
    """Create an interactive web dashboard (placeholder)"""
    print("\n" + "="*60)
    print("INTERACTIVE DASHBOARD")
    print("="*60)
    print("""
To create an interactive dashboard, you could use:

1. Streamlit:
   ```python
   import streamlit as st
   
   st.title("Multi-Agent System Dashboard")
   
   # Agent status
   for name, agent in system.agents.items():
       st.metric(name, agent.state.status)
   
   # Workflow progress
   for wf_id, wf in system.workflows.items():
       st.progress(wf.completion_percentage)
   ```

2. Flask + Socket.IO for real-time updates

3. React frontend with WebSocket connection
    """)


# Example usage
if __name__ == "__main__":
    from orchestrator import MultiAgentSystem
    
    # Create a sample system
    system = MultiAgentSystem("Demo System")
    system.create_standard_team()
    
    # Create visualizer
    viz = AgentVisualizer(system)
    
    # Generate report
    print(viz.generate_system_report())
