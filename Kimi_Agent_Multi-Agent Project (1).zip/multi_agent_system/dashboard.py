"""
Streamlit Dashboard for Multi-Agent System

Run: streamlit run dashboard.py
"""
import streamlit as st
import json
from datetime import datetime

from orchestrator import MultiAgentSystem
from specialized_agents import ResearchAgent, AnalysisAgent, WriterAgent, CriticAgent

# Page config
st.set_page_config(
    page_title="Multi-Agent System",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'system' not in st.session_state:
    st.session_state.system = None
if 'results' not in st.session_state:
    st.session_state.results = []


def init_system(name="Dashboard System"):
    """Initialize the multi-agent system"""
    system = MultiAgentSystem(name)
    system.create_standard_team()
    return system


# Sidebar
st.sidebar.title("🤖 Multi-Agent System")

# System initialization
st.sidebar.header("System")
system_name = st.sidebar.text_input("System Name", value="My Team")

if st.sidebar.button("Initialize System"):
    st.session_state.system = init_system(system_name)
    st.sidebar.success(f"✅ System '{system_name}' initialized!")

if st.sidebar.button("Reset System"):
    st.session_state.system = None
    st.session_state.results = []
    st.sidebar.info("System reset")

# Main content
st.title("🚀 Multi-Agent Collaboration Platform")

if st.session_state.system is None:
    st.info("👈 Initialize a system from the sidebar to get started!")
    
    st.markdown("""
    ## Welcome to the Multi-Agent System!
    
    This platform allows you to:
    - 🔬 **Research** - Gather information on any topic
    - 📊 **Analyze** - Extract insights from data
    - ✍️ **Write** - Generate structured reports
    - 🔍 **Review** - Get quality feedback
    
    ### Quick Start
    1. Enter a system name in the sidebar
    2. Click "Initialize System"
    3. Use the tabs below to interact with your agents
    """)
else:
    system = st.session_state.system
    
    # Tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🔬 Research", "👥 Agents", "📋 Workflows", "📊 Status"
    ])
    
    # Tab 1: Research
    with tab1:
        st.header("Research Pipeline")
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            topic = st.text_input(
                "Research Topic",
                placeholder="Enter a topic to research...",
                key="research_topic"
            )
        
        with col2:
            depth = st.selectbox(
                "Research Depth",
                ["shallow", "medium", "deep"],
                index=1
            )
        
        if st.button("🚀 Start Research", type="primary"):
            if topic:
                with st.spinner(f"Researching '{topic}'..."):
                    result = system.run_research_pipeline(topic, depth=depth)
                    st.session_state.results.append({
                        "topic": topic,
                        "result": result,
                        "timestamp": datetime.now()
                    })
                
                st.success("✅ Research completed!")
                
                # Display results
                writer_output = result.get('results', {}).get('step_3', {})
                critic_output = result.get('results', {}).get('step_4', {})
                
                st.subheader("Generated Report")
                st.markdown(writer_output.get('content', 'No content generated'))
                
                st.subheader("Review Feedback")
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Score", f"{critic_output.get('overall_score', 0)}/100")
                with col2:
                    st.metric("Word Count", writer_output.get('word_count', 0))
                with col3:
                    approved = "✅ Yes" if critic_output.get('approved') else "❌ No"
                    st.metric("Approved", approved)
                
                # Score breakdown
                with st.expander("Detailed Scores"):
                    scores = critic_output.get('scores', {})
                    for category, score in scores.items():
                        st.progress(score / 100, text=f"{category.capitalize()}: {score}")
            else:
                st.warning("Please enter a topic")
        
        # Previous results
        if st.session_state.results:
            st.divider()
            st.subheader("Previous Research")
            for i, res in enumerate(reversed(st.session_state.results[-5:])):
                with st.expander(f"📄 {res['topic']} ({res['timestamp'].strftime('%H:%M:%S')})"):
                    writer_out = res['result'].get('results', {}).get('step_3', {})
                    st.markdown(writer_out.get('content', '')[:500] + "...")
    
    # Tab 2: Agents
    with tab2:
        st.header("Agent Management")
        
        agents_data = []
        for name, agent in system.agents.items():
            agents_data.append({
                "Name": name,
                "Role": agent.role,
                "Status": agent.state.status,
                "Tasks Completed": len(agent.state.completed_tasks),
                "Inbox": len(agent.inbox),
                "Outbox": len(agent.outbox)
            })
        
        st.dataframe(agents_data, use_container_width=True)
        
        # Agent details
        st.subheader("Agent Details")
        selected_agent = st.selectbox(
            "Select Agent",
            list(system.agents.keys())
        )
        
        if selected_agent:
            agent = system.agents[selected_agent]
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Status", agent.state.status)
            with col2:
                st.metric("Completed Tasks", len(agent.state.completed_tasks))
            with col3:
                st.metric("Peers", len(agent.peers))
            
            with st.expander("Completed Tasks"):
                for task in agent.state.completed_tasks:
                    st.write(f"- {task}")
            
            with st.expander("Memory"):
                for entry in agent.memory[-10:]:
                    st.write(f"- {entry['type']}: {entry['message']['msg_type']}")
    
    # Tab 3: Workflows
    with tab3:
        st.header("Workflow Management")
        
        if system.workflows:
            workflows_data = []
            for wf_id, wf in system.workflows.items():
                workflows_data.append({
                    "ID": wf_id,
                    "Name": wf.name,
                    "Status": wf.status,
                    "Steps": len(wf.steps),
                    "Created": wf.created_at.strftime("%Y-%m-%d %H:%M")
                })
            
            st.dataframe(workflows_data, use_container_width=True)
            
            # Workflow details
            st.subheader("Workflow Details")
            selected_wf = st.selectbox(
                "Select Workflow",
                list(system.workflows.keys())
            )
            
            if selected_wf:
                wf = system.workflows[selected_wf]
                
                st.write(f"**Name:** {wf.name}")
                st.write(f"**Status:** {wf.status}")
                
                # Steps visualization
                st.subheader("Steps")
                for step in wf.steps:
                    status_emoji = {
                        "pending": "⏳",
                        "running": "🔄",
                        "completed": "✅",
                        "failed": "❌"
                    }.get(step.status, "❓")
                    
                    st.write(f"{status_emoji} **{step.step_id}**: {step.action} ({step.agent_name})")
                    if step.depends_on:
                        st.caption(f"   Depends on: {', '.join(step.depends_on)}")
        else:
            st.info("No workflows created yet. Run a research pipeline to create one!")
    
    # Tab 4: Status
    with tab4:
        st.header("System Status")
        
        status = system.get_system_status()
        
        # Overview metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Agents", status['agents_count'])
        with col2:
            st.metric("Total Workflows", status['workflows_count'])
        with col3:
            active_agents = sum(1 for a in status['agents'].values() if a['status'] == 'working')
            st.metric("Active Agents", active_agents)
        
        # Agent statuses
        st.subheader("Agent Statuses")
        agent_cols = st.columns(min(len(status['agents']), 4))
        
        for i, (name, agent_status) in enumerate(status['agents'].items()):
            with agent_cols[i % 4]:
                status_color = {
                    "idle": "gray",
                    "working": "orange",
                    "completed": "green",
                    "error": "red"
                }.get(agent_status['status'], "gray")
                
                st.markdown(f"""
                <div style="padding: 10px; border-radius: 5px; background-color: {'#e8f5e9' if agent_status['status'] == 'completed' else '#fff3e0' if agent_status['status'] == 'working' else '#f5f5f5'};">
                    <b>{name}</b><br>
                    <small>{agent_status['role']}</small><br>
                    <span style="color: {status_color}">●</span> {agent_status['status']}
                </div>
                """, unsafe_allow_html=True)

# Footer
st.divider()
st.caption("Multi-Agent System v1.0.0 | Built with Streamlit")
