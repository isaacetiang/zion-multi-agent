"""
Specialized Agents Module - Concrete agent implementations
"""
import re
import json
from typing import Dict, List, Any, Optional
from datetime import datetime
from agent_base import Agent, Message, MessageType


class ResearchAgent(Agent):
    """
    Research Agent - Gathers and organizes information
    
    Capabilities:
    - Search for information (simulated)
    - Extract key facts and data points
    - Organize findings by category
    - Provide sources and references
    """
    
    def __init__(self, name: str = "Researcher"):
        super().__init__(
            name=name,
            role="research",
            description="Gathers and organizes information on topics"
        )
        self.knowledge_base: Dict[str, List[Dict]] = {}
        self.search_history: List[str] = []
    
    def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute research task"""
        self.update_state(status="working", current_task=task.get("topic"))
        
        topic = task.get("topic", "")
        depth = task.get("depth", "medium")  # shallow, medium, deep
        
        print(f"\n🔍 [{self.name}] Researching: '{topic}' (depth: {depth})")
        
        # Simulate research process
        findings = self._simulate_research(topic, depth)
        
        # Store in knowledge base
        self.knowledge_base[topic] = findings
        self.search_history.append(topic)
        
        # Update state
        self.update_state(
            status="completed",
            completed_tasks=self.state.completed_tasks + [topic]
        )
        
        result = {
            "topic": topic,
            "findings": findings,
            "sources_count": len(findings),
            "timestamp": datetime.now().isoformat()
        }
        
        print(f"✅ [{self.name}] Completed research on '{topic}' - Found {len(findings)} key points")
        
        return result
    
    def _simulate_research(self, topic: str, depth: str) -> List[Dict]:
        """Simulate research process - in real use, would call search APIs"""
        depth_multiplier = {"shallow": 3, "medium": 5, "deep": 8}
        count = depth_multiplier.get(depth, 5)
        
        # Generate simulated findings based on topic keywords
        findings = []
        keywords = topic.lower().split()
        
        templates = [
            {"category": "definition", "content": f"{topic} refers to a comprehensive approach in its domain"},
            {"category": "history", "content": f"The concept of {topic} emerged in the early development phase"},
            {"category": "application", "content": f"{topic} is widely applied across multiple industries"},
            {"category": "benefits", "content": f"Key benefits of {topic} include efficiency and scalability"},
            {"category": "challenges", "content": f"Common challenges in {topic} involve integration complexity"},
            {"category": "trends", "content": f"Current trends show growing adoption of {topic} methodologies"},
            {"category": "statistics", "content": f"Research indicates 40-60% improvement with {topic} implementation"},
            {"category": "future", "content": f"Future developments in {topic} point toward AI integration"},
        ]
        
        for i in range(min(count, len(templates))):
            finding = templates[i].copy()
            finding["id"] = f"{topic.replace(' ', '_')}_{i+1}"
            finding["confidence"] = round(0.7 + 0.25 * (i % 3) / 2, 2)
            findings.append(finding)
        
        return findings
    
    def _handle_query(self, message: Message):
        """Handle information queries from other agents"""
        query = message.content
        print(f"📨 [{self.name}] Received query from {message.sender}: {query}")
        
        # Search knowledge base
        relevant_info = []
        for topic, findings in self.knowledge_base.items():
            if any(kw in topic.lower() or kw in str(findings).lower() 
                   for kw in query.lower().split()):
                relevant_info.extend(findings)
        
        # Send response
        self.send_message(
            recipient=message.sender,
            content={
                "query": query,
                "results": relevant_info[:5],
                "source": self.name
            },
            msg_type=MessageType.RESPONSE,
            metadata={"in_response_to": message.msg_id}
        )


class AnalysisAgent(Agent):
    """
    Analysis Agent - Processes and analyzes information
    
    Capabilities:
    - Pattern recognition
    - Trend analysis
    - Comparative analysis
    - Insight generation
    """
    
    def __init__(self, name: str = "Analyst"):
        super().__init__(
            name=name,
            role="analysis",
            description="Analyzes information to extract insights and patterns"
        )
        self.analyses: List[Dict] = []
        self.insights: List[str] = []
    
    def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute analysis task"""
        self.update_state(status="working", current_task="analysis")
        
        data = task.get("data", [])
        analysis_type = task.get("type", "general")
        
        print(f"\n📊 [{self.name}] Performing {analysis_type} analysis on {len(data)} data points")
        
        # Perform analysis
        analysis_result = self._analyze(data, analysis_type)
        
        # Store analysis
        self.analyses.append({
            "type": analysis_type,
            "timestamp": datetime.now().isoformat(),
            "result": analysis_result
        })
        
        self.update_state(
            status="completed",
            completed_tasks=self.state.completed_tasks + [f"analysis_{len(self.analyses)}"]
        )
        
        print(f"✅ [{self.name}] Analysis complete - Generated {len(analysis_result.get('insights', []))} insights")
        
        return analysis_result
    
    def _analyze(self, data: List[Any], analysis_type: str) -> Dict[str, Any]:
        """Perform analysis based on type"""
        insights = []
        patterns = []
        recommendations = []
        
        if analysis_type == "trend":
            insights.append("Upward trajectory observed in key metrics")
            patterns.append("Cyclical patterns detected with 3-month periods")
            recommendations.append("Continue current strategy with quarterly reviews")
            
        elif analysis_type == "comparative":
            insights.append("Significant variance between groups identified")
            patterns.append("Correlation coefficient of 0.78 between variables")
            recommendations.append("Focus on high-performing segments")
            
        elif analysis_type == "risk":
            insights.append("Medium risk level with manageable exposure")
            patterns.append("Risk concentrated in specific areas")
            recommendations.append("Implement mitigation strategies for identified risks")
            
        else:  # general
            insights.append("Data shows consistent performance across categories")
            patterns.append("Stable baseline with occasional outliers")
            recommendations.append("Maintain monitoring protocols")
        
        # Extract key metrics
        key_metrics = {
            "data_points": len(data),
            "confidence_score": round(0.75 + 0.15 * (len(data) % 3) / 2, 2),
            "analysis_depth": analysis_type
        }
        
        return {
            "insights": insights,
            "patterns": patterns,
            "recommendations": recommendations,
            "metrics": key_metrics,
            "analyzed_at": datetime.now().isoformat()
        }
    
    def _handle_task(self, message: Message):
        """Handle analysis tasks"""
        task = message.content
        if isinstance(task, dict) and task.get("type") == "analysis_request":
            result = self.execute(task)
            self.send_message(
                recipient=message.sender,
                content=result,
                msg_type=MessageType.RESULT,
                metadata={"task_id": task.get("id")}
            )


class WriterAgent(Agent):
    """
    Writer Agent - Creates and edits content
    
    Capabilities:
    - Content generation
    - Summarization
    - Style adaptation
    - Quality editing
    """
    
    def __init__(self, name: str = "Writer"):
        super().__init__(
            name=name,
            role="writing",
            description="Creates well-structured content from information"
        )
        self.drafts: List[Dict] = []
        self.writing_style = "professional"
    
    def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute writing task"""
        self.update_state(status="working", current_task="writing")
        
        content_type = task.get("content_type", "report")
        data = task.get("data", {})
        style = task.get("style", self.writing_style)
        
        print(f"\n✍️  [{self.name}] Creating {content_type} in {style} style")
        
        # Generate content
        content = self._generate_content(content_type, data, style)
        
        draft = {
            "type": content_type,
            "style": style,
            "content": content,
            "word_count": len(content.split()),
            "created_at": datetime.now().isoformat()
        }
        self.drafts.append(draft)
        
        self.update_state(
            status="completed",
            completed_tasks=self.state.completed_tasks + [f"draft_{len(self.drafts)}"]
        )
        
        print(f"✅ [{self.name}] Draft complete - {draft['word_count']} words")
        
        return draft
    
    def _generate_content(self, content_type: str, data: Dict, style: str) -> str:
        """Generate content based on type and style"""
        
        if content_type == "report":
            return self._generate_report(data, style)
        elif content_type == "summary":
            return self._generate_summary(data, style)
        elif content_type == "article":
            return self._generate_article(data, style)
        else:
            return self._generate_generic(data, style)
    
    def _generate_report(self, data: Dict, style: str) -> str:
        """Generate structured report"""
        topic = data.get("topic", "Subject")
        findings = data.get("findings", [])
        analysis = data.get("analysis", {})
        
        sections = [
            f"# {topic} - Comprehensive Report",
            "",
            "## Executive Summary",
            f"This report presents a detailed examination of {topic}, incorporating research findings and analytical insights.",
            "",
            "## Key Findings",
        ]
        
        for i, finding in enumerate(findings[:5], 1):
            sections.append(f"{i}. **{finding.get('category', 'Point').title()}**: {finding.get('content', '')}")
        
        sections.extend([
            "",
            "## Analysis",
        ])
        
        for insight in analysis.get("insights", []):
            sections.append(f"- {insight}")
        
        sections.extend([
            "",
            "## Recommendations",
        ])
        
        for rec in analysis.get("recommendations", []):
            sections.append(f"- {rec}")
        
        sections.extend([
            "",
            "## Conclusion",
            f"The analysis of {topic} reveals significant opportunities for strategic advancement based on the evidence presented.",
        ])
        
        return "\n".join(sections)
    
    def _generate_summary(self, data: Dict, style: str) -> str:
        """Generate concise summary"""
        topic = data.get("topic", "Subject")
        key_points = data.get("key_points", [])
        
        lines = [
            f"## Summary: {topic}",
            "",
            "### Overview",
            f"{topic} represents a critical area of focus with multiple dimensions worth exploring.",
            "",
            "### Key Points",
        ]
        
        for point in key_points[:5]:
            lines.append(f"- {point}")
        
        lines.extend([
            "",
            "### Takeaway",
            f"Understanding {topic} is essential for informed decision-making in the relevant domain.",
        ])
        
        return "\n".join(lines)
    
    def _generate_article(self, data: Dict, style: str) -> str:
        """Generate article-style content"""
        topic = data.get("topic", "Subject")
        
        return f"""# Understanding {topic}: A Deep Dive

In today's rapidly evolving landscape, {topic} has emerged as a pivotal consideration for professionals across industries. This article explores the fundamental aspects and practical implications.

## The Foundation

At its core, {topic} represents a paradigm shift in how we approach challenges and opportunities. The integration of innovative methodologies has transformed traditional practices.

## Key Insights

Recent developments highlight several important trends:

- Increased adoption across diverse sectors
- Measurable improvements in efficiency and outcomes
- Growing recognition of long-term benefits

## Looking Forward

As we continue to navigate an increasingly complex environment, {topic} will undoubtedly play a crucial role in shaping future strategies and solutions.
"""
    
    def _generate_generic(self, data: Dict, style: str) -> str:
        """Generate generic content"""
        return f"Content generated based on provided data: {json.dumps(data, indent=2)[:500]}..."


class CriticAgent(Agent):
    """
    Critic Agent - Reviews and provides feedback
    
    Capabilities:
    - Quality assessment
    - Error detection
    - Improvement suggestions
    - Fact-checking
    """
    
    def __init__(self, name: str = "Critic"):
        super().__init__(
            name=name,
            role="review",
            description="Reviews content and provides constructive feedback"
        )
        self.reviews: List[Dict] = []
        self.criteria = ["accuracy", "clarity", "completeness", "structure", "style"]
    
    def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute review task"""
        self.update_state(status="working", current_task="reviewing")
        
        content = task.get("content", "")
        content_type = task.get("content_type", "general")
        
        print(f"\n🔍 [{self.name}] Reviewing {content_type}")
        
        # Perform review
        review = self._review_content(content, content_type)
        self.reviews.append(review)
        
        self.update_state(
            status="completed",
            completed_tasks=self.state.completed_tasks + [f"review_{len(self.reviews)}"]
        )
        
        print(f"✅ [{self.name}] Review complete - Score: {review['overall_score']}/100")
        
        return review
    
    def _review_content(self, content: str, content_type: str) -> Dict[str, Any]:
        """Review content against criteria"""
        scores = {}
        feedback = []
        
        # Score each criterion (simulated)
        for criterion in self.criteria:
            base_score = 75
            if criterion == "accuracy":
                base_score += 10
            elif criterion == "clarity":
                base_score += 5
            scores[criterion] = min(95, base_score + (len(content) % 15))
        
        # Generate feedback
        avg_score = sum(scores.values()) / len(scores)
        
        if avg_score >= 85:
            feedback.append("Excellent work with strong overall quality")
            feedback.append("Minor refinements could enhance impact")
        elif avg_score >= 70:
            feedback.append("Good foundation with room for improvement")
            feedback.append("Consider addressing identified gaps")
        else:
            feedback.append("Significant revisions recommended")
            feedback.append("Focus on core clarity and structure")
        
        # Specific suggestions
        suggestions = [
            "Consider adding more specific examples",
            "Verify all factual claims",
            "Improve transitions between sections",
            "Add visual elements where appropriate",
            "Consider alternative phrasing for complex concepts"
        ]
        
        return {
            "overall_score": round(avg_score, 1),
            "scores": scores,
            "feedback": feedback,
            "suggestions": suggestions[:3],
            "content_type": content_type,
            "reviewed_at": datetime.now().isoformat(),
            "approved": avg_score >= 75
        }
    
    def _handle_task(self, message: Message):
        """Handle review requests"""
        task = message.content
        if isinstance(task, dict) and task.get("type") == "review_request":
            result = self.execute(task)
            self.send_message(
                recipient=message.sender,
                content=result,
                msg_type=MessageType.RESULT,
                metadata={"task_id": task.get("id")}
            )


class CoordinatorAgent(Agent):
    """
    Coordinator Agent - Manages workflow and task distribution
    
    Capabilities:
    - Task decomposition
    - Agent coordination
    - Progress monitoring
    - Conflict resolution
    """
    
    def __init__(self, name: str = "Coordinator"):
        super().__init__(
            name=name,
            role="coordination",
            description="Orchestrates multi-agent collaboration"
        )
        self.workflows: List[Dict] = []
        self.active_tasks: Dict[str, Dict] = {}
        self.task_history: List[Dict] = []
    
    def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute coordination task"""
        self.update_state(status="working", current_task="coordination")
        
        operation = task.get("operation", "coordinate")
        
        if operation == "create_workflow":
            return self._create_workflow(task)
        elif operation == "assign_task":
            return self._assign_task(task)
        elif operation == "monitor":
            return self._monitor_progress()
        else:
            return {"status": "unknown_operation"}
    
    def _create_workflow(self, task: Dict) -> Dict:
        """Create a new workflow"""
        workflow_id = f"wf_{len(self.workflows) + 1}"
        workflow = {
            "id": workflow_id,
            "name": task.get("name", "Unnamed Workflow"),
            "steps": task.get("steps", []),
            "status": "created",
            "created_at": datetime.now().isoformat()
        }
        self.workflows.append(workflow)
        
        print(f"\n📋 [{self.name}] Created workflow: {workflow['name']} ({workflow_id})")
        
        return {"workflow_id": workflow_id, "status": "created"}
    
    def _assign_task(self, task: Dict) -> Dict:
        """Assign task to appropriate agent"""
        agent_name = task.get("agent")
        task_details = task.get("task", {})
        
        if agent_name in self.peers:
            self.send_message(
                recipient=agent_name,
                content=task_details,
                msg_type=MessageType.TASK,
                metadata={"assigned_by": self.name}
            )
            
            task_id = f"task_{len(self.active_tasks) + 1}"
            self.active_tasks[task_id] = {
                "agent": agent_name,
                "task": task_details,
                "status": "assigned",
                "assigned_at": datetime.now().isoformat()
            }
            
            print(f"📤 [{self.name}] Assigned task to {agent_name}")
            
            return {"task_id": task_id, "assigned_to": agent_name, "status": "assigned"}
        
        return {"error": f"Agent {agent_name} not found"}
    
    def _monitor_progress(self) -> Dict:
        """Monitor progress of all agents"""
        statuses = {}
        for name, agent in self.peers.items():
            statuses[name] = agent.get_status()
        
        return {
            "agent_statuses": statuses,
            "active_tasks": len(self.active_tasks),
            "completed_tasks": len(self.task_history),
            "timestamp": datetime.now().isoformat()
        }
    
    def broadcast_task(self, task: Dict, agent_names: List[str] = None):
        """Broadcast task to multiple agents"""
        targets = agent_names or list(self.peers.keys())
        
        for agent_name in targets:
            if agent_name in self.peers:
                self.send_message(
                    recipient=agent_name,
                    content=task,
                    msg_type=MessageType.TASK
                )
        
        print(f"📢 [{self.name}] Broadcasted task to {len(targets)} agents")
