#!/bin/bash
# Deployment Script for Multi-Agent System

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║        Multi-Agent System - Deployment Script                ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

show_help() {
    echo "Usage: ./deploy.sh [OPTION]"
    echo ""
    echo "Options:"
    echo "  local       Run locally with Python"
    echo "  docker      Build and run with Docker"
    echo "  api         Start API server"
    echo "  dashboard   Start Streamlit dashboard"
    echo "  compose     Run with Docker Compose"
    echo "  test        Run tests"
    echo "  help        Show this help"
    echo ""
}

check_python() {
    if ! command -v python3 &> /dev/null; then
        echo "❌ Python 3 is not installed"
        exit 1
    fi
    echo -e "${GREEN}✅ Python 3 found${NC}"
}

check_docker() {
    if ! command -v docker &> /dev/null; then
        echo "❌ Docker is not installed"
        exit 1
    fi
    echo -e "${GREEN}✅ Docker found${NC}"
}

deploy_local() {
    echo -e "${BLUE}▶️  Deploying locally...${NC}"
    check_python
    
    echo "📦 Installing dependencies..."
    pip install -q -e ".[all]" 2>/dev/null || pip install -q -e .
    
    echo "🚀 Running demo..."
    python demo.py
}

deploy_docker() {
    echo -e "${BLUE}▶️  Deploying with Docker...${NC}"
    check_docker
    
    echo "🐳 Building Docker image..."
    docker build -t multi-agent-system .
    
    echo "🚀 Running container..."
    docker run -it --rm multi-agent-system
}

deploy_api() {
    echo -e "${BLUE}▶️  Starting API server...${NC}"
    check_python
    
    echo "📦 Installing dependencies..."
    pip install -q flask flask-cors gunicorn 2>/dev/null
    
    echo "🌐 Starting server on http://localhost:5000"
    echo "Press Ctrl+C to stop"
    echo ""
    
    python api.py
}

deploy_dashboard() {
    echo -e "${BLUE}▶️  Starting Streamlit dashboard...${NC}"
    check_python
    
    echo "📦 Installing dependencies..."
    pip install -q streamlit 2>/dev/null
    
    echo "🌐 Starting dashboard on http://localhost:8501"
    echo "Press Ctrl+C to stop"
    echo ""
    
    streamlit run dashboard.py
}

deploy_compose() {
    echo -e "${BLUE}▶️  Deploying with Docker Compose...${NC}"
    check_docker
    
    echo "🐳 Starting services..."
    docker-compose up --build
}

run_tests() {
    echo -e "${BLUE}▶️  Running tests...${NC}"
    check_python
    
    echo "🧪 Testing imports..."
    python -c "from orchestrator import MultiAgentSystem; print('✅ Orchestrator OK')"
    python -c "from specialized_agents import ResearchAgent; print('✅ Agents OK')"
    python -c "from agent_base import Agent; print('✅ Base Agent OK')"
    
    echo ""
    echo -e "${GREEN}✅ All tests passed!${NC}"
}

# Main
case "$1" in
    local)
        deploy_local
        ;;
    docker)
        deploy_docker
        ;;
    api)
        deploy_api
        ;;
    dashboard)
        deploy_dashboard
        ;;
    compose)
        deploy_compose
        ;;
    test)
        run_tests
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo -e "${YELLOW}Please specify a deployment option${NC}"
        show_help
        exit 1
        ;;
esac
